import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Neha Tiwari - Web Developer and Mobile Developer',
  description: 'Professional portfolio of Neha Tiwari, a skilled Web Developer and Mobile Developer with 3.8+ years of experience in React.js, React Native, Flutter, and modern web technologies.',
  keywords: 'Neha Tiwari, Web Developer, Mobile Developer, React Native, Flutter, React.js',
  authors: [{ name: 'Neha Tiwari' }],
  openGraph: {
    title: 'Neha Tiwari - Web Developer and Mobile Developer',
    description: 'Professional portfolio showcasing web and mobile development expertise',
    type: 'website',
  },
  robots: {
    index: true,
    follow: true,
  },
  viewport: {
    width: 'device-width',
    initialScale: 1,
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  )
}
